import numpy as np
import gym
from gym import spaces

class AviatorGame:
    def simulate_round(self):
        crash_point = np.random.exponential(scale=1.5) + 1
        return round(min(crash_point, 100), 2)

    def play(self, cashout_multiplier):
        crash_point = self.simulate_round()
        win = cashout_multiplier <= crash_point
        reward = cashout_multiplier if win else 0
        return crash_point, win, reward

class AviatorEnv(gym.Env):
    def __init__(self):
        super(AviatorEnv, self).__init__()
        self.game = AviatorGame()
        self.history_length = 10
        self.action_space = spaces.Box(low=np.array([1.01]), high=np.array([5.0]), dtype=np.float32)
        self.observation_space = spaces.Box(low=1.0, high=100.0, shape=(self.history_length,), dtype=np.float32)
        self.history = np.ones(self.history_length)

    def reset(self):
        self.history = np.ones(self.history_length)
        return self.history

    def step(self, action):
        action = float(action[0])
        crash, win, reward = self.game.play(action)
        self.history = np.roll(self.history, -1)
        self.history[-1] = crash
        done = False
        return self.history, reward, done, {}
