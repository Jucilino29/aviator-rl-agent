import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from aviator_env import AviatorEnv
from stable_baselines3 import PPO

@st.cache_resource
def load_model():
    env = AviatorEnv()
    model = PPO.load("model/ppo_aviator", env=env)
    return model, env

model, env = load_model()

if "obs" not in st.session_state:
    st.session_state.obs = env.reset()
    st.session_state.rewards = []
    st.session_state.actions = []
    st.session_state.crashes = []
    st.session_state.total_reward = 0

st.title("🎮 Aviator AI - Agente com Aprendizado por Reforço")
st.write("Simulação do agente PPO jogando o Aviator.")

if st.button("▶️ Jogar uma rodada"):
    action, _ = model.predict(st.session_state.obs)
    obs, reward, done, _ = env.step(action)
    st.session_state.obs = obs
    st.session_state.actions.append(float(action[0]))
    st.session_state.rewards.append(reward)
    st.session_state.crashes.append(float(obs[-1]))
    st.session_state.total_reward += reward

st.metric("Último crash", f"{st.session_state.obs[-1]:.2f}x")
st.metric("Último cashout", f"{st.session_state.actions[-1]:.2f}x" if st.session_state.actions else "N/A")
st.metric("Lucro acumulado", f"{st.session_state.total_reward:.2f}")

if st.session_state.rewards:
    st.subheader("📊 Desempenho")
    fig, ax = plt.subplots(2, 1, figsize=(8, 6), sharex=True)

    ax[0].plot(st.session_state.actions, label="Cashout")
    ax[0].plot(st.session_state.crashes, label="Crash", linestyle='--')
    ax[0].legend()
    ax[0].set_ylabel("Multiplicador")

    ax[1].plot(np.cumsum(st.session_state.rewards), label="Lucro", color='green')
    ax[1].set_ylabel("Lucro acumulado")
    ax[1].set_xlabel("Rodadas")

    st.pyplot(fig)

if st.button("🔄 Reiniciar"):
    st.session_state.obs = env.reset()
    st.session_state.rewards.clear()
    st.session_state.actions.clear()
    st.session_state.crashes.clear()
    st.session_state.total_reward = 0
