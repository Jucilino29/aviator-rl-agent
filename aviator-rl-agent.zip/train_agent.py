from aviator_env import AviatorEnv
from stable_baselines3 import PPO

env = AviatorEnv()
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=100_000)

# Salvar o modelo
model.save("model/ppo_aviator")
